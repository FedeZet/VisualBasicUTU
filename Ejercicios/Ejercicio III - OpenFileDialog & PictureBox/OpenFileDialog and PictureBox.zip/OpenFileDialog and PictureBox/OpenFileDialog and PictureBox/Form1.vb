﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim errores As String = ""

        If TextBox1.Text = "" Then
            errores &= "- El nombre no puede estar vacio " & vbCrLf
        End If

        If TextBox2.Text.Length < 6 Then
            errores &= "- La contraseña debe tener mínimo 6 caracteres " & vbCrLf
        End If

        If DateDiff(DateInterval.Year, DateTimePicker1.Value, Date.Now) < 18 Then
            errores &= "- El usuario debe tener 18 o más años " & vbCrLf
        End If

        If IsNothing(PictureBox1.Image) Then
            errores &= "- Debes elegir una imagen " & vbCrLf
        End If

        If errores = "" Then
            MsgBox("Usuario correcto e insertado.")
        Else
            MsgBox(errores)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        OpenFileDialog1.Filter = "JPG |*.jpg"
        Dim eleccion As Integer = OpenFileDialog1.ShowDialog(Me)

        If eleccion = DialogResult.OK Then
            PictureBox1.Image = System.Drawing.Image.FromFile(OpenFileDialog1.FileName)
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
