﻿Module Calculos

    Public Contador As Integer = 0
    Public Ganadas As Integer = 0
    Public Porcentaje As Integer

End Module
