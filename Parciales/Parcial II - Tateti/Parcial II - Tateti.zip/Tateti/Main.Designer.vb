﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.btnCasilla7 = New System.Windows.Forms.Button()
        Me.btnCasilla8 = New System.Windows.Forms.Button()
        Me.btnCasilla9 = New System.Windows.Forms.Button()
        Me.btnCasilla4 = New System.Windows.Forms.Button()
        Me.btnCasilla5 = New System.Windows.Forms.Button()
        Me.btnCasilla6 = New System.Windows.Forms.Button()
        Me.btnCasilla1 = New System.Windows.Forms.Button()
        Me.btnCasilla2 = New System.Windows.Forms.Button()
        Me.btnCasilla3 = New System.Windows.Forms.Button()
        Me.lblTitulo = New System.Windows.Forms.Label()
        Me.lblTurno = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCasilla7
        '
        Me.btnCasilla7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla7.Location = New System.Drawing.Point(56, 179)
        Me.btnCasilla7.Name = "btnCasilla7"
        Me.btnCasilla7.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla7.TabIndex = 0
        Me.btnCasilla7.TabStop = False
        Me.btnCasilla7.UseVisualStyleBackColor = True
        '
        'btnCasilla8
        '
        Me.btnCasilla8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla8.Location = New System.Drawing.Point(112, 179)
        Me.btnCasilla8.Name = "btnCasilla8"
        Me.btnCasilla8.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla8.TabIndex = 1
        Me.btnCasilla8.TabStop = False
        Me.btnCasilla8.UseVisualStyleBackColor = True
        '
        'btnCasilla9
        '
        Me.btnCasilla9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla9.Location = New System.Drawing.Point(168, 179)
        Me.btnCasilla9.Name = "btnCasilla9"
        Me.btnCasilla9.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla9.TabIndex = 2
        Me.btnCasilla9.TabStop = False
        Me.btnCasilla9.UseVisualStyleBackColor = True
        '
        'btnCasilla4
        '
        Me.btnCasilla4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla4.Location = New System.Drawing.Point(56, 123)
        Me.btnCasilla4.Name = "btnCasilla4"
        Me.btnCasilla4.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla4.TabIndex = 3
        Me.btnCasilla4.TabStop = False
        Me.btnCasilla4.UseVisualStyleBackColor = True
        '
        'btnCasilla5
        '
        Me.btnCasilla5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla5.Location = New System.Drawing.Point(112, 123)
        Me.btnCasilla5.Name = "btnCasilla5"
        Me.btnCasilla5.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla5.TabIndex = 4
        Me.btnCasilla5.TabStop = False
        Me.btnCasilla5.UseVisualStyleBackColor = True
        '
        'btnCasilla6
        '
        Me.btnCasilla6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla6.Location = New System.Drawing.Point(168, 123)
        Me.btnCasilla6.Name = "btnCasilla6"
        Me.btnCasilla6.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla6.TabIndex = 5
        Me.btnCasilla6.TabStop = False
        Me.btnCasilla6.UseVisualStyleBackColor = True
        '
        'btnCasilla1
        '
        Me.btnCasilla1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla1.Location = New System.Drawing.Point(56, 67)
        Me.btnCasilla1.Name = "btnCasilla1"
        Me.btnCasilla1.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla1.TabIndex = 6
        Me.btnCasilla1.TabStop = False
        Me.btnCasilla1.UseVisualStyleBackColor = True
        '
        'btnCasilla2
        '
        Me.btnCasilla2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla2.Location = New System.Drawing.Point(112, 67)
        Me.btnCasilla2.Name = "btnCasilla2"
        Me.btnCasilla2.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla2.TabIndex = 7
        Me.btnCasilla2.TabStop = False
        Me.btnCasilla2.UseVisualStyleBackColor = True
        '
        'btnCasilla3
        '
        Me.btnCasilla3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCasilla3.Location = New System.Drawing.Point(168, 67)
        Me.btnCasilla3.Name = "btnCasilla3"
        Me.btnCasilla3.Size = New System.Drawing.Size(50, 50)
        Me.btnCasilla3.TabIndex = 8
        Me.btnCasilla3.TabStop = False
        Me.btnCasilla3.UseVisualStyleBackColor = True
        '
        'lblTitulo
        '
        Me.lblTitulo.Font = New System.Drawing.Font("Microsoft YaHei", 18.25!, System.Drawing.FontStyle.Bold)
        Me.lblTitulo.Location = New System.Drawing.Point(56, 9)
        Me.lblTitulo.Name = "lblTitulo"
        Me.lblTitulo.Size = New System.Drawing.Size(162, 33)
        Me.lblTitulo.TabIndex = 9
        Me.lblTitulo.Text = "Ta Te Ti"
        Me.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTurno
        '
        Me.lblTurno.Location = New System.Drawing.Point(83, 51)
        Me.lblTurno.Name = "lblTurno"
        Me.lblTurno.Size = New System.Drawing.Size(113, 13)
        Me.lblTurno.TabIndex = 10
        Me.lblTurno.Text = "Seleccione una casilla"
        Me.lblTurno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(273, 240)
        Me.Controls.Add(Me.lblTurno)
        Me.Controls.Add(Me.lblTitulo)
        Me.Controls.Add(Me.btnCasilla3)
        Me.Controls.Add(Me.btnCasilla2)
        Me.Controls.Add(Me.btnCasilla1)
        Me.Controls.Add(Me.btnCasilla6)
        Me.Controls.Add(Me.btnCasilla5)
        Me.Controls.Add(Me.btnCasilla4)
        Me.Controls.Add(Me.btnCasilla9)
        Me.Controls.Add(Me.btnCasilla8)
        Me.Controls.Add(Me.btnCasilla7)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ta Te Ti"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnCasilla7 As Button
    Friend WithEvents btnCasilla8 As Button
    Friend WithEvents btnCasilla9 As Button
    Friend WithEvents btnCasilla4 As Button
    Friend WithEvents btnCasilla5 As Button
    Friend WithEvents btnCasilla6 As Button
    Friend WithEvents btnCasilla1 As Button
    Friend WithEvents btnCasilla2 As Button
    Friend WithEvents btnCasilla3 As Button
    Friend WithEvents lblTitulo As Label
    Friend WithEvents lblTurno As Label
End Class
